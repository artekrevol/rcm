# Design System Documentation

A comprehensive guide to the visual design system used in this project.

---

## 🎨 Color Palette

All colors use HSL format for consistency and easy theming.

### Core Colors

| Token | Light Mode | Dark Mode | Usage |
|-------|------------|-----------|-------|
| `--background` | `210 20% 98%` | `220 20% 8%` | Page backgrounds |
| `--foreground` | `220 20% 10%` | `210 20% 95%` | Primary text |
| `--card` | `0 0% 100%` | `220 18% 12%` | Card surfaces |
| `--card-foreground` | `220 20% 10%` | `210 20% 95%` | Card text |

### Brand Colors

| Token | Light Mode | Dark Mode | Usage |
|-------|------------|-----------|-------|
| `--primary` | `210 100% 45%` | `210 100% 55%` | Primary actions, links |
| `--primary-foreground` | `0 0% 100%` | `0 0% 100%` | Text on primary |
| `--secondary` | `210 20% 96%` | `220 15% 18%` | Secondary buttons |
| `--secondary-foreground` | `220 20% 20%` | `210 20% 90%` | Text on secondary |

### Semantic Colors

| Token | Light Mode | Dark Mode | Usage |
|-------|------------|-----------|-------|
| `--success` | `142 70% 45%` | `142 60% 40%` | Positive states, revenue |
| `--warning` | `38 92% 50%` | `38 80% 45%` | Alerts, attention |
| `--destructive` | `0 72% 51%` | `0 62% 45%` | Errors, delete actions |
| `--risk` | `0 84% 60%` | `0 70% 50%` | High-risk indicators |

### UI Colors

| Token | Light Mode | Dark Mode | Usage |
|-------|------------|-----------|-------|
| `--muted` | `210 15% 95%` | `220 15% 18%` | Muted backgrounds |
| `--muted-foreground` | `220 10% 45%` | `215 15% 60%` | Secondary text |
| `--accent` | `210 60% 95%` | `220 15% 20%` | Highlights |
| `--accent-foreground` | `210 100% 40%` | `210 100% 65%` | Accent text |
| `--border` | `214 20% 90%` | `220 15% 20%` | Borders |
| `--input` | `214 20% 90%` | `220 15% 20%` | Input borders |
| `--ring` | `210 100% 45%` | `210 100% 55%` | Focus rings |

### Sidebar Colors

| Token | Value | Usage |
|-------|-------|-------|
| `--sidebar-background` | `220 20% 8%` / `220 25% 6%` | Sidebar bg |
| `--sidebar-foreground` | `210 20% 90%` | Sidebar text |
| `--sidebar-primary` | `210 100% 55%` / `210 100% 60%` | Active items |
| `--sidebar-accent` | `220 15% 15%` / `220 20% 12%` | Hover states |
| `--sidebar-border` | `220 15% 18%` / `220 15% 15%` | Dividers |

### Chart Colors

| Token | Value | Usage |
|-------|-------|-------|
| `--chart-1` | `210 100% 50%` | Primary data |
| `--chart-2` | `142 70% 45%` | Success/growth |
| `--chart-3` | `38 92% 50%` | Warning/neutral |
| `--chart-4` | `280 65% 60%` | Accent data |
| `--chart-5` | `0 72% 55%` | Risk/negative |

---

## 📝 Typography

### Font Family

```css
font-sans: "Inter", system-ui, sans-serif
```

### Type Scale

| Class | Size | Weight | Usage |
|-------|------|--------|-------|
| `text-xs` | 12px | 400 | Captions, labels |
| `text-sm` | 14px | 400-500 | Body text, UI elements |
| `text-base` | 16px | 400 | Default body |
| `text-lg` | 18px | 500-600 | Subheadings |
| `text-xl` | 20px | 600 | Section titles |
| `text-2xl` | 24px | 600-700 | Page titles |

### Font Weights

| Weight | Value | Usage |
|--------|-------|-------|
| `font-normal` | 400 | Body text |
| `font-medium` | 500 | Labels, buttons |
| `font-semibold` | 600 | Headings, emphasis |
| `font-bold` | 700 | Strong emphasis |

---

## 📐 Spacing & Layout

### Border Radius

| Token | Value | Usage |
|-------|-------|-------|
| `--radius` | `0.625rem` (10px) | Default radius |
| `rounded-sm` | `calc(--radius - 4px)` | Small elements |
| `rounded-md` | `calc(--radius - 2px)` | Medium elements |
| `rounded-lg` | `var(--radius)` | Cards, buttons |
| `rounded-full` | `9999px` | Pills, avatars |

### Shadows

| Class | Value | Usage |
|-------|-------|-------|
| `shadow-soft` | `0 2px 8px -2px rgba(0,0,0,0.08), 0 4px 16px -4px rgba(0,0,0,0.06)` | Subtle elevation |
| `shadow-card` | `0 1px 3px rgba(0,0,0,0.04), 0 4px 12px rgba(0,0,0,0.06)` | Cards |
| `shadow-elevated` | `0 4px 20px -4px rgba(0,0,0,0.1), 0 8px 32px -8px rgba(0,0,0,0.08)` | Modals, popovers |

---

## 🎬 Animations

### Keyframes

| Name | Description | Duration |
|------|-------------|----------|
| `fade-in` | Fade + slide up 8px | 300ms |
| `slide-in-right` | Fade + slide left 16px | 300ms |
| `count-up` | Fade + slide up 4px | 500ms |
| `pulse` | Opacity 1 → 0.5 → 1 | 2000ms |
| `accordion-down/up` | Height animation | 200ms |

### Usage

```tsx
className="animate-fade-in"
className="animate-slide-in-right"
className="animate-pulse"
```

---

## 🧩 Component Specifications

### Chat Widget Components

#### ChatHeader
- **Height**: 56px (py-3 px-4)
- **Background**: `bg-card`
- **Border**: `border-b border-border/50`
- **Logo**: 40x40px rounded-lg with `bg-primary/10`
- **Title**: `text-sm font-semibold`
- **Subtitle**: `text-xs text-muted-foreground`

#### ChatAnnouncement
- **Padding**: `px-3 py-2`
- **Background**: `bg-primary`
- **Text**: `text-primary-foreground text-xs`
- **Dismiss**: 16x16px ghost button

#### ChatWelcome
- **Avatar**: 64x64px outer, 48x48px inner
- **Avatar gradient**: `from-primary/20 to-primary/5` (outer), `from-primary to-primary/80` (inner)
- **Animation**: `animate-pulse` on inner avatar
- **Spacing**: `space-y-4`

#### ChatPillButtons
- **Question badge**: `bg-foreground/90 text-background` rounded-lg
- **Pills**: `rounded-full px-4 h-9`
- **Selected state**: `bg-primary text-primary-foreground`
- **Unselected state**: `border-border/60 bg-card`

#### ChatStackedButtons
- **Width**: Full width
- **Height**: `h-auto py-3 px-4`
- **Border**: `border-border/60`
- **Hover**: `hover:bg-muted/50 hover:border-primary/30`

#### ChatPricing
- **Price text**: `text-primary font-semibold`
- **Bullet points**: 6x6px `bg-primary` circles
- **CTA buttons**: Full width, `h-11`

#### ChatLoading
- **Spinner**: 64x64px container, 32x32px icon
- **Steps**: Checkmark (completed), Spinner (active), Empty (pending)
- **Dots**: 8x8px with staggered `animate-pulse`

#### ChatInput
- **Container**: `border-t border-border/50 bg-card`
- **Input**: Transparent, no border, no ring
- **Send button**: 36x36px rounded-full
- **Feedback buttons**: `text-xs text-muted-foreground`

---

## 🎯 Utility Classes

### Gradient Backgrounds

```css
.bg-gradient-primary   /* Primary blue gradient */
.bg-gradient-success   /* Green success gradient */
```

### Metric Cards

```css
.metric-blue   /* Light blue gradient bg */
.metric-green  /* Light green gradient bg */
.metric-amber  /* Light amber gradient bg */
.metric-red    /* Light red gradient bg */
```

### Card Effects

```css
.card-hover    /* Hover: shadow-md, -translate-y-0.5 */
```

---

## 📱 Responsive Breakpoints

| Breakpoint | Min Width | Usage |
|------------|-----------|-------|
| `sm` | 640px | Mobile landscape |
| `md` | 768px | Tablets |
| `lg` | 1024px | Desktop |
| `xl` | 1280px | Large desktop |
| `2xl` | 1400px | Container max-width |

---

## 🔧 Usage in Code

### Using Color Tokens

```tsx
// ✅ Correct - Use semantic tokens
<div className="bg-primary text-primary-foreground" />
<div className="bg-card border-border" />
<div className="text-muted-foreground" />

// ❌ Incorrect - Don't use raw colors
<div className="bg-blue-500 text-white" />
```

### Importing in Tailwind

All tokens are available via Tailwind classes:

```tsx
<Button className="bg-success text-success-foreground" />
<Badge className="bg-warning text-warning-foreground" />
<Alert className="bg-risk/10 text-risk" />
```

---

## 📦 Dependencies

- **Tailwind CSS** - Utility-first CSS
- **tailwindcss-animate** - Animation utilities
- **shadcn/ui** - Component primitives
- **Lucide React** - Icon library
- **class-variance-authority** - Component variants
- **clsx** + **tailwind-merge** - Class utilities
