import { Calendar, Tag, LayoutGrid, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface SuggestionButton {
  icon: React.ReactNode;
  label: string;
  value: string;
}

interface ChatWelcomeProps {
  agentName?: string;
  welcomeMessage: string;
  subMessage?: string;
  suggestions: SuggestionButton[];
  onSelect: (value: string) => void;
}

export function ChatWelcome({ 
  welcomeMessage, 
  subMessage,
  suggestions, 
  onSelect 
}: ChatWelcomeProps) {
  return (
    <div className="space-y-4 animate-fade-in">
      {/* Animated avatar */}
      <div className="flex justify-center">
        <div className="relative">
          <div className="h-16 w-16 rounded-full bg-gradient-to-br from-primary/20 to-primary/5 flex items-center justify-center">
            <div className="h-12 w-12 rounded-full bg-gradient-to-br from-primary to-primary/80 flex items-center justify-center animate-pulse">
              <svg viewBox="0 0 24 24" className="h-6 w-6 text-primary-foreground" fill="currentColor">
                <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/>
              </svg>
            </div>
          </div>
        </div>
      </div>

      {/* Welcome text */}
      <div className="text-center space-y-1.5">
        <p className="text-sm text-foreground leading-relaxed">{welcomeMessage}</p>
        {subMessage && (
          <p className="text-sm font-medium text-foreground">{subMessage}</p>
        )}
      </div>

      {/* Suggestions label */}
      <div className="pt-2">
        <p className="text-xs font-medium text-muted-foreground mb-3">Suggestions</p>
        
        {/* Suggestion buttons - stacked with icons */}
        <div className="space-y-2">
          {suggestions.map((suggestion) => (
            <Button
              key={suggestion.value}
              variant="outline"
              className={cn(
                "w-full justify-start gap-3 h-auto py-3 px-4",
                "border-border/60 bg-card hover:bg-muted/50 hover:border-primary/30",
                "text-sm font-medium text-foreground",
                "transition-all duration-200"
              )}
              onClick={() => onSelect(suggestion.value)}
            >
              <span className="text-primary">{suggestion.icon}</span>
              {suggestion.label}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
}

export const DEFAULT_SUGGESTIONS = [
  { icon: <Calendar className="h-4 w-4" />, label: "Schedule a tour", value: "Schedule a tour" },
  { icon: <Tag className="h-4 w-4" />, label: "View starting prices", value: "Get Pricing" },
  { icon: <LayoutGrid className="h-4 w-4" />, label: "View floorplans", value: "View floorplans" },
];
