import { Check, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface LoadingStep {
  label: string;
  completed: boolean;
  active: boolean;
}

interface ChatLoadingProps {
  title?: string;
  steps: LoadingStep[];
  message?: string;
}

export function ChatLoading({ 
  title = "Please wait...", 
  steps,
  message 
}: ChatLoadingProps) {
  return (
    <div className="space-y-4 animate-fade-in">
      {/* Animated icon */}
      <div className="flex justify-center">
        <div className="relative">
          <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center">
            <Loader2 className="h-8 w-8 text-primary animate-spin" />
          </div>
        </div>
      </div>

      {/* Title */}
      <h3 className="text-center text-lg font-semibold text-foreground">{title}</h3>

      {/* Loading animation */}
      <div className="flex justify-center">
        <div className="flex gap-1">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="h-2 w-2 rounded-full bg-primary/60 animate-pulse"
              style={{ animationDelay: `${i * 150}ms` }}
            />
          ))}
        </div>
      </div>

      {/* Steps checklist */}
      <div className="space-y-2">
        {steps.map((step, index) => (
          <div 
            key={index}
            className={cn(
              "flex items-center gap-2 text-sm transition-colors",
              step.completed ? "text-foreground" : "text-muted-foreground"
            )}
          >
            {step.completed ? (
              <Check className="h-4 w-4 text-success shrink-0" />
            ) : step.active ? (
              <Loader2 className="h-4 w-4 text-primary animate-spin shrink-0" />
            ) : (
              <div className="h-4 w-4 shrink-0" />
            )}
            {step.label}
          </div>
        ))}
      </div>

      {/* Message */}
      {message && (
        <p className="text-sm text-muted-foreground text-center leading-relaxed pt-2">
          {message}
        </p>
      )}
    </div>
  );
}
