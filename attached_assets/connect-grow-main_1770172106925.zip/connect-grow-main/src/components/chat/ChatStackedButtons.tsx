import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface StackedOption {
  label: string;
  value: string;
}

interface ChatStackedButtonsProps {
  question: string;
  options: StackedOption[];
  onSelect: (value: string) => void;
}

export function ChatStackedButtons({ 
  question, 
  options, 
  onSelect 
}: ChatStackedButtonsProps) {
  return (
    <div className="space-y-3 animate-fade-in">
      <div className="inline-block bg-foreground/90 text-background text-sm font-medium px-3 py-1.5 rounded-lg">
        {question}
      </div>
      
      <div className="space-y-2">
        {options.map((option) => (
          <Button
            key={option.value}
            variant="outline"
            className={cn(
              "w-full justify-center h-11 text-sm font-medium",
              "border-primary/20 bg-primary/5 hover:bg-primary hover:text-primary-foreground",
              "text-primary transition-all duration-200"
            )}
            onClick={() => onSelect(option.value)}
          >
            {option.label}
          </Button>
        ))}
      </div>
    </div>
  );
}
