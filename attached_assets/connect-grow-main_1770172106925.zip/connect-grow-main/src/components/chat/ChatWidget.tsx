import { useState, useRef, useEffect } from "react";
import { MessageCircle, Calendar, Tag, LayoutGrid } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ChatHeader } from "./ChatHeader";
import { ChatAnnouncement } from "./ChatAnnouncement";
import { ChatWelcome } from "./ChatWelcome";
import { ChatPillButtons } from "./ChatPillButtons";
import { ChatStackedButtons } from "./ChatStackedButtons";
import { ChatPricing } from "./ChatPricing";
import { ChatLoading } from "./ChatLoading";
import { ChatInput } from "./ChatInput";

type ChatStep =
  | "welcome"
  | "treatment"
  | "beneficiary"
  | "contact"
  | "pricing"
  | "loading"
  | "complete";

const WELCOME_SUGGESTIONS = [
  { icon: <Calendar className="h-4 w-4" />, label: "Schedule a tour", value: "Schedule a tour" },
  { icon: <Tag className="h-4 w-4" />, label: "View starting prices", value: "Get Pricing" },
  { icon: <LayoutGrid className="h-4 w-4" />, label: "View floorplans", value: "View floorplans" },
];

const TREATMENT_OPTIONS = [
  { label: "Inpatient", value: "Inpatient" },
  { label: "Outpatient", value: "Outpatient" },
  { label: "Detox", value: "Detox" },
  { label: "PHP", value: "PHP" },
  { label: "IOP", value: "IOP" },
  { label: "Not Sure", value: "Not Sure" },
];

const BENEFICIARY_OPTIONS = [
  { label: "Myself", value: "Myself" },
  { label: "Spouse", value: "Spouse" },
  { label: "Child", value: "Child" },
  { label: "Parent", value: "Parent" },
  { label: "Friend", value: "Friend" },
  { label: "Other", value: "Other" },
];

const PRICING_DATA = {
  options: [
    { service: "Inpatient Treatment", price: "starting at $15,000" },
    { service: "Outpatient Program", price: "starting at $5,000" },
    { service: "Detox Program", price: "starting at $8,000" },
  ],
  message: "Someone will be in touch to provide more detailed pricing shortly. Please schedule a visit to learn more about Claim Shield Treatment Center.",
  includedServices: [
    "Medical Assessment & Monitoring",
    "24/7 Clinical Support",
    "Individual & Group Therapy",
    "Aftercare Planning"
  ]
};

const LOADING_STEPS = [
  { label: "Analyzing your info", completed: true, active: false },
  { label: "Checking for availability", completed: true, active: false },
  { label: "Extending conversation to text message.", completed: false, active: true },
];

export function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [step, setStep] = useState<ChatStep>("welcome");
  const [showAnnouncement, setShowAnnouncement] = useState(true);
  const [selectedTreatment, setSelectedTreatment] = useState<string[]>([]);
  const [inputValue, setInputValue] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [step]);

  const handleWelcomeSelect = (value: string) => {
    if (value === "Get Pricing") {
      setStep("treatment");
    } else if (value === "Schedule a tour") {
      setStep("beneficiary");
    } else {
      setStep("treatment");
    }
  };

  const handleTreatmentSelect = (value: string) => {
    if (selectedTreatment.includes(value)) {
      setSelectedTreatment(prev => prev.filter(v => v !== value));
    } else {
      setSelectedTreatment(prev => [...prev, value]);
    }
    // Auto-advance after selection
    setTimeout(() => {
      setStep("beneficiary");
    }, 500);
  };

  const handleBeneficiarySelect = (value: string) => {
    setStep("loading");
    // Simulate loading then show pricing
    setTimeout(() => {
      setStep("pricing");
    }, 2500);
  };

  const handleScheduleVisit = () => {
    setStep("complete");
  };

  const handleAskQuestion = () => {
    setStep("welcome");
  };

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;
    setInputValue("");
    // Handle message send
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className={cn(
          "fixed bottom-6 right-6 z-50",
          "flex h-14 w-14 items-center justify-center",
          "rounded-full bg-primary",
          "text-primary-foreground shadow-lg",
          "transition-all duration-300 hover:scale-105 hover:shadow-xl",
          "active:scale-95"
        )}
      >
        <MessageCircle className="h-6 w-6" />
        <Badge 
          className={cn(
            "absolute -right-1 -top-1",
            "h-5 min-w-5 rounded-full border-2 border-background",
            "bg-success text-success-foreground",
            "p-0 text-[10px] font-semibold",
            "flex items-center justify-center"
          )}
        >
          1
        </Badge>
      </button>
    );
  }

  return (
    <div
      className={cn(
        "fixed bottom-6 right-6 z-50",
        "flex w-[380px] flex-col overflow-hidden",
        "rounded-2xl bg-card",
        "border border-border/50 shadow-xl",
        "h-[600px]"
      )}
    >
      {/* Announcement banner */}
      {showAnnouncement && (
        <ChatAnnouncement 
          message="We are now open! Visit every Monday through Friday, 9:00 AM to 5:00 PM."
          onDismiss={() => setShowAnnouncement(false)}
        />
      )}

      {/* Header */}
      <ChatHeader 
        title="Care Assistant"
        subtitle="Claim Shield Treatment"
        onClose={() => setIsOpen(false)}
      />

      {/* Content */}
      <ScrollArea className="flex-1">
        <div ref={scrollRef} className="p-4">
          {step === "welcome" && (
            <ChatWelcome
              welcomeMessage="Hi, this is your Care Assistant with Claim Shield Treatment Center. I'm a virtual assistant here to help answer any questions you may have about our programs."
              subMessage="How can I help you today?"
              suggestions={WELCOME_SUGGESTIONS}
              onSelect={handleWelcomeSelect}
            />
          )}

          {step === "treatment" && (
            <ChatPillButtons
              question="What level of care are you interested in?"
              options={TREATMENT_OPTIONS}
              selectedValues={selectedTreatment}
              onSelect={handleTreatmentSelect}
              multiSelect
            />
          )}

          {step === "beneficiary" && (
            <ChatStackedButtons
              question="Who is this for?"
              options={BENEFICIARY_OPTIONS}
              onSelect={handleBeneficiarySelect}
            />
          )}

          {step === "loading" && (
            <ChatLoading
              title="Please wait..."
              steps={LOADING_STEPS}
              message="Let's continue this conversation through text message! You will be connected with a team member who will quickly find exactly what you need."
            />
          )}

          {step === "pricing" && (
            <ChatPricing
              options={PRICING_DATA.options}
              message={PRICING_DATA.message}
              includedServices={PRICING_DATA.includedServices}
              onScheduleVisit={handleScheduleVisit}
              onAskQuestion={handleAskQuestion}
              onOutOfBudget={() => setStep("welcome")}
            />
          )}

          {step === "complete" && (
            <div className="text-center space-y-4 animate-fade-in py-8">
              <div className="h-16 w-16 mx-auto rounded-full bg-success/10 flex items-center justify-center">
                <svg viewBox="0 0 24 24" className="h-8 w-8 text-success" fill="currentColor">
                  <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-foreground">Thank You!</h3>
              <p className="text-sm text-muted-foreground">
                Our team will be in touch shortly to help schedule your visit.
              </p>
            </div>
          )}
        </div>
      </ScrollArea>

      {/* Input */}
      <ChatInput
        value={inputValue}
        onChange={setInputValue}
        onSend={handleSendMessage}
        showFeedback={step !== "welcome" && step !== "loading"}
        onFeedback={(helpful) => console.log("Feedback:", helpful)}
      />
    </div>
  );
}
