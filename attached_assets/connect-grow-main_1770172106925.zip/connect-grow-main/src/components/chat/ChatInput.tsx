import { Send, ThumbsUp, ThumbsDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";

interface ChatInputProps {
  value: string;
  onChange: (value: string) => void;
  onSend: () => void;
  placeholder?: string;
  showFeedback?: boolean;
  onFeedback?: (helpful: boolean) => void;
}

export function ChatInput({ 
  value, 
  onChange, 
  onSend, 
  placeholder = "Type here...",
  showFeedback = false,
  onFeedback
}: ChatInputProps) {
  return (
    <div className="border-t border-border/50 bg-card">
      {/* Feedback buttons */}
      {showFeedback && onFeedback && (
        <div className="flex items-center gap-4 px-4 py-2 border-b border-border/30">
          <button
            onClick={() => onFeedback(true)}
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            <ThumbsUp className="h-3.5 w-3.5" />
            Helpful
          </button>
          <button
            onClick={() => onFeedback(false)}
            className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
          >
            <ThumbsDown className="h-3.5 w-3.5" />
            Not helpful
          </button>
        </div>
      )}
      
      {/* Input area */}
      <div className="flex items-center gap-2 p-3">
        <Input
          placeholder={placeholder}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && onSend()}
          className={cn(
            "flex-1 border-0 bg-transparent shadow-none",
            "focus-visible:ring-0 focus-visible:ring-offset-0",
            "placeholder:text-muted-foreground/60"
          )}
        />
        <Button 
          size="icon" 
          onClick={onSend}
          disabled={!value.trim()}
          className={cn(
            "h-9 w-9 rounded-full shrink-0",
            "bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground",
            "disabled:opacity-30 disabled:bg-muted disabled:text-muted-foreground",
            "transition-all duration-200"
          )}
        >
          <Send className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}
