import { X, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ChatAnnouncementProps {
  message: string;
  onDismiss: () => void;
}

export function ChatAnnouncement({ message, onDismiss }: ChatAnnouncementProps) {
  return (
    <div className="flex items-center gap-2 bg-primary px-4 py-2.5 text-primary-foreground">
      <Sparkles className="h-4 w-4 shrink-0" />
      <p className="flex-1 text-xs font-medium">{message}</p>
      <Button
        variant="ghost"
        size="icon"
        className="h-6 w-6 shrink-0 text-primary-foreground/80 hover:text-primary-foreground hover:bg-primary-foreground/10"
        onClick={onDismiss}
      >
        <X className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}
