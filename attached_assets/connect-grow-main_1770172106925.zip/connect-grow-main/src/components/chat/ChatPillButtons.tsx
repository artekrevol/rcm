import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface PillOption {
  label: string;
  value: string;
}

interface ChatPillButtonsProps {
  question: string;
  options: PillOption[];
  selectedValues?: string[];
  onSelect: (value: string) => void;
  multiSelect?: boolean;
}

export function ChatPillButtons({ 
  question, 
  options, 
  selectedValues = [],
  onSelect,
  multiSelect = false 
}: ChatPillButtonsProps) {
  return (
    <div className="space-y-3 animate-fade-in">
      <div className="inline-block bg-foreground/90 text-background text-sm font-medium px-3 py-1.5 rounded-lg">
        {question}
      </div>
      
      <div className="flex flex-wrap gap-2">
        {options.map((option) => {
          const isSelected = selectedValues.includes(option.value);
          return (
            <Button
              key={option.value}
              variant={isSelected ? "default" : "outline"}
              size="sm"
              className={cn(
                "rounded-full px-4 h-9 text-sm font-medium transition-all duration-200",
                isSelected 
                  ? "bg-primary text-primary-foreground shadow-sm" 
                  : "border-border/60 bg-card hover:bg-muted/50 hover:border-primary/30 text-foreground"
              )}
              onClick={() => onSelect(option.value)}
            >
              {option.label}
            </Button>
          );
        })}
      </div>
    </div>
  );
}
