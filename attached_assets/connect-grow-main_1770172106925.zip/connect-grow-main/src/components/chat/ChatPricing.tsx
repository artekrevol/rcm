import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface PricingOption {
  service: string;
  price: string;
}

interface ChatPricingProps {
  options: PricingOption[];
  message?: string;
  includedServices?: string[];
  onScheduleVisit: () => void;
  onAskQuestion: () => void;
  onOutOfBudget: () => void;
}

export function ChatPricing({ 
  options, 
  message,
  includedServices,
  onScheduleVisit,
  onAskQuestion,
  onOutOfBudget
}: ChatPricingProps) {
  return (
    <div className="space-y-4 animate-fade-in">
      {/* Pricing list */}
      <div className="space-y-3">
        {options.map((option, index) => (
          <div 
            key={index}
            className="flex items-center justify-between py-1"
          >
            <span className="text-sm text-foreground">{option.service}</span>
            <span className="text-sm font-semibold text-primary">{option.price}</span>
          </div>
        ))}
      </div>

      {/* Message */}
      {message && (
        <p className="text-sm text-muted-foreground leading-relaxed">
          {message}
        </p>
      )}

      {/* Included services */}
      {includedServices && includedServices.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm font-medium text-foreground">Services included with monthly rent:</p>
          <ul className="space-y-1">
            {includedServices.map((service, index) => (
              <li key={index} className="flex items-center gap-2 text-sm text-muted-foreground">
                <span className="h-1.5 w-1.5 rounded-full bg-primary shrink-0" />
                {service}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Action buttons */}
      <div className="space-y-2 pt-2">
        <Button
          className="w-full h-11 font-medium"
          onClick={onScheduleVisit}
        >
          Schedule A Visit
        </Button>
        <Button
          variant="outline"
          className="w-full h-11 font-medium border-primary/20 text-primary hover:bg-primary/5"
          onClick={onAskQuestion}
        >
          Ask A Question
        </Button>
        <Button
          variant="outline"
          className="w-full h-11 font-medium border-primary/20 text-primary hover:bg-primary/5"
          onClick={onOutOfBudget}
        >
          Out Of My Budget
        </Button>
      </div>
    </div>
  );
}
