import {
  TrendingUp,
  TrendingDown,
  ShieldCheck,
  AlertTriangle,
  Clock,
  Building2,
  ArrowUpRight,
  Bell,
  ExternalLink,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts";

const metrics = [
  {
    title: "Denials Prevented",
    value: "156",
    change: "+12%",
    trend: "up",
    icon: ShieldCheck,
    color: "metric-green",
  },
  {
    title: "Claims at Risk",
    value: "23",
    change: "-8%",
    trend: "down",
    icon: AlertTriangle,
    color: "metric-amber",
  },
  {
    title: "Avg AR Days",
    value: "34.2",
    change: "-3 days",
    trend: "down",
    icon: Clock,
    color: "metric-blue",
  },
  {
    title: "Top Payer Risk",
    value: "Aetna",
    change: "12 claims",
    trend: "neutral",
    icon: Building2,
    color: "metric-red",
  },
];

const chartData = [
  { month: "Jul", claims: 420, prevented: 38, denials: 12 },
  { month: "Aug", claims: 450, prevented: 45, denials: 15 },
  { month: "Sep", claims: 480, prevented: 52, denials: 10 },
  { month: "Oct", claims: 520, prevented: 65, denials: 8 },
  { month: "Nov", claims: 560, prevented: 78, denials: 14 },
  { month: "Dec", claims: 540, prevented: 85, denials: 11 },
  { month: "Jan", claims: 580, prevented: 92, denials: 9 },
];

const alerts = [
  {
    id: 1,
    type: "high",
    title: "Missing prior auth for 3 claims",
    description: "Claims CLM-2024-001, CLM-2024-002, CLM-2024-003",
    time: "5 min ago",
  },
  {
    id: 2,
    type: "medium",
    title: "Eligibility expires in 7 days",
    description: "Patient John Doe - Aetna PPO",
    time: "1 hour ago",
  },
  {
    id: 3,
    type: "low",
    title: "New denial pattern detected",
    description: "CPT 99213 with Cigna - 8 denials this week",
    time: "2 hours ago",
  },
  {
    id: 4,
    type: "medium",
    title: "Claim stuck in pending for 15 days",
    description: "CLM-2024-156 - United Healthcare",
    time: "3 hours ago",
  },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Dashboard</h1>
          <p className="text-sm text-muted-foreground">
            Revenue cycle overview and real-time alerts
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            Last 30 Days
          </Button>
          <Button size="sm">
            <Bell className="mr-2 h-4 w-4" />
            View All Alerts
          </Button>
        </div>
      </div>

      {/* Metrics row */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {metrics.map((metric) => (
          <Card key={metric.title} className={`card-hover ${metric.color}`}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="space-y-2">
                  <p className="text-sm font-medium text-muted-foreground">
                    {metric.title}
                  </p>
                  <p className="text-3xl font-bold tracking-tight">
                    {metric.value}
                  </p>
                  <div className="flex items-center gap-1 text-sm">
                    {metric.trend === "up" && (
                      <TrendingUp className="h-4 w-4 text-success" />
                    )}
                    {metric.trend === "down" && (
                      <TrendingDown className="h-4 w-4 text-success" />
                    )}
                    <span
                      className={
                        metric.trend !== "neutral"
                          ? "text-success"
                          : "text-muted-foreground"
                      }
                    >
                      {metric.change}
                    </span>
                    <span className="text-muted-foreground">vs last month</span>
                  </div>
                </div>
                <div className="rounded-lg bg-background/50 p-2">
                  <metric.icon className="h-5 w-5 text-muted-foreground" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts and Alerts row */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Monthly Trend Chart */}
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-base font-medium">
              Monthly Trends
            </CardTitle>
            <div className="flex gap-1">
              {["Week", "Month", "Quarter", "Year"].map((period) => (
                <Button
                  key={period}
                  variant={period === "Month" ? "secondary" : "ghost"}
                  size="sm"
                  className="h-7 text-xs"
                >
                  {period}
                </Button>
              ))}
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis
                    dataKey="month"
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                  />
                  <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="claims"
                    stroke="hsl(var(--chart-1))"
                    strokeWidth={2}
                    dot={false}
                    name="Total Claims"
                  />
                  <Line
                    type="monotone"
                    dataKey="prevented"
                    stroke="hsl(var(--chart-2))"
                    strokeWidth={2}
                    dot={false}
                    name="Prevented"
                  />
                  <Line
                    type="monotone"
                    dataKey="denials"
                    stroke="hsl(var(--chart-5))"
                    strokeWidth={2}
                    dot={false}
                    name="Denials"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Revenue Protection */}
        <div className="space-y-6">
          <Card className="bg-gradient-primary text-primary-foreground">
            <CardContent className="p-6">
              <p className="text-sm font-medium opacity-90">Revenue Protected</p>
              <p className="mt-2 text-4xl font-bold tracking-tight">$2.4M</p>
              <p className="mt-1 text-sm opacity-80">
                From prevented denials this quarter
              </p>
              <Button
                variant="secondary"
                size="sm"
                className="mt-4"
              >
                View Details
                <ArrowUpRight className="ml-1 h-4 w-4" />
              </Button>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card>
            <CardContent className="grid grid-cols-2 gap-4 p-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-primary">94%</p>
                <p className="text-xs text-muted-foreground">Clean Claim Rate</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-success">$180K</p>
                <p className="text-xs text-muted-foreground">Saved This Week</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Active Alerts */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between pb-2">
          <CardTitle className="text-base font-medium">Active Alerts</CardTitle>
          <Button variant="ghost" size="sm">
            View All
            <ExternalLink className="ml-1 h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {alerts.map((alert) => (
              <div
                key={alert.id}
                className="flex items-start gap-3 rounded-lg border p-3 transition-colors hover:bg-muted/50"
              >
                <div
                  className={`mt-0.5 h-2 w-2 shrink-0 rounded-full ${
                    alert.type === "high"
                      ? "bg-risk"
                      : alert.type === "medium"
                      ? "bg-warning"
                      : "bg-muted-foreground"
                  }`}
                />
                <div className="flex-1 space-y-1">
                  <p className="text-sm font-medium leading-none">
                    {alert.title}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {alert.description}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-muted-foreground">
                    {alert.time}
                  </span>
                  <Button variant="ghost" size="sm" className="h-7">
                    View
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
