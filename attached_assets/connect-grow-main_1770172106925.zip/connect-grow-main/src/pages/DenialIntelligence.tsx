import {
  TrendingUp,
  TrendingDown,
  ExternalLink,
  ChevronRight,
  Lightbulb,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const patternData = [
  { reason: "Missing Prior Auth", count: 45, pct: 28 },
  { reason: "Medical Necessity", count: 38, pct: 24 },
  { reason: "Timely Filing", count: 25, pct: 16 },
  { reason: "Duplicate Claim", count: 18, pct: 11 },
  { reason: "Coding Error", count: 15, pct: 9 },
  { reason: "Eligibility", count: 12, pct: 8 },
  { reason: "Other", count: 7, pct: 4 },
];

const topPatterns = [
  {
    id: 1,
    payer: "Aetna",
    cptCode: "99213",
    reason: "Missing Prior Auth",
    count: 12,
    trend: "up",
    trendValue: "+4",
    revenue: "$28,800",
  },
  {
    id: 2,
    payer: "Cigna",
    cptCode: "90837",
    reason: "Medical Necessity",
    count: 9,
    trend: "up",
    trendValue: "+2",
    revenue: "$21,600",
  },
  {
    id: 3,
    payer: "United Healthcare",
    cptCode: "99214",
    reason: "Timely Filing",
    count: 7,
    trend: "down",
    trendValue: "-3",
    revenue: "$15,400",
  },
  {
    id: 4,
    payer: "Blue Cross",
    cptCode: "90834",
    reason: "Coding Error",
    count: 5,
    trend: "neutral",
    trendValue: "0",
    revenue: "$9,000",
  },
];

const patternCards = [
  {
    id: 1,
    payer: "Aetna",
    cptCode: "99213",
    category: "Authorization",
    count: 12,
    trend: "up",
    color: "border-risk",
  },
  {
    id: 2,
    payer: "Cigna",
    cptCode: "90837",
    category: "Medical Necessity",
    count: 9,
    trend: "up",
    color: "border-warning",
  },
  {
    id: 3,
    payer: "United",
    cptCode: "99214",
    category: "Timely Filing",
    count: 7,
    trend: "down",
    color: "border-warning",
  },
  {
    id: 4,
    payer: "Blue Cross",
    cptCode: "90834",
    category: "Coding",
    count: 5,
    trend: "neutral",
    color: "border-muted",
  },
  {
    id: 5,
    payer: "Aetna",
    cptCode: "90837",
    category: "Eligibility",
    count: 4,
    trend: "down",
    color: "border-muted",
  },
  {
    id: 6,
    payer: "Cigna",
    cptCode: "99215",
    category: "Duplicate",
    count: 3,
    trend: "neutral",
    color: "border-muted",
  },
];

export default function DenialIntelligence() {
  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Denial Intelligence
          </h1>
          <p className="text-sm text-muted-foreground">
            Pattern analysis and prevention insights
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            Last 30 Days
          </Button>
          <Button size="sm">
            <ExternalLink className="mr-2 h-4 w-4" />
            Export Analysis
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="card-hover">
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground">Total Denials</p>
            <p className="mt-1 text-3xl font-bold">160</p>
            <p className="mt-1 text-sm text-risk">+12% vs last month</p>
          </CardContent>
        </Card>
        <Card className="card-hover">
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground">Revenue at Risk</p>
            <p className="mt-1 text-3xl font-bold">$384K</p>
            <p className="mt-1 text-sm text-muted-foreground">From active denials</p>
          </CardContent>
        </Card>
        <Card className="card-hover">
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground">Patterns Detected</p>
            <p className="mt-1 text-3xl font-bold">7</p>
            <p className="mt-1 text-sm text-warning">3 new this week</p>
          </CardContent>
        </Card>
        <Card className="card-hover">
          <CardContent className="p-6">
            <p className="text-sm text-muted-foreground">Appeal Success</p>
            <p className="mt-1 text-3xl font-bold">68%</p>
            <p className="mt-1 text-sm text-success">+5% improvement</p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Pattern Chart */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-base font-medium">
              Denial Patterns by Root Cause
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={patternData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                  <YAxis
                    type="category"
                    dataKey="reason"
                    stroke="hsl(var(--muted-foreground))"
                    fontSize={12}
                    width={120}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "8px",
                    }}
                    formatter={(value: number, name: string) => [
                      `${value} denials`,
                      "Count",
                    ]}
                  />
                  <Bar dataKey="count" fill="hsl(var(--chart-5))" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Top Patterns Sidebar */}
        <Card>
          <CardHeader>
            <CardTitle className="text-base font-medium">Top Patterns</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {topPatterns.map((pattern) => (
              <div
                key={pattern.id}
                className="flex items-start justify-between rounded-lg border p-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{pattern.payer}</span>
                    <Badge variant="outline" className="text-xs">
                      {pattern.cptCode}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{pattern.reason}</p>
                  <p className="text-xs text-muted-foreground">
                    {pattern.revenue} at risk
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <Badge variant="secondary">{pattern.count}</Badge>
                  <div className="flex items-center gap-1">
                    {pattern.trend === "up" && (
                      <TrendingUp className="h-3 w-3 text-risk" />
                    )}
                    {pattern.trend === "down" && (
                      <TrendingDown className="h-3 w-3 text-success" />
                    )}
                    <span
                      className={`text-xs ${
                        pattern.trend === "up"
                          ? "text-risk"
                          : pattern.trend === "down"
                          ? "text-success"
                          : "text-muted-foreground"
                      }`}
                    >
                      {pattern.trendValue}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Pattern Cards Grid */}
      <div>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-medium">All Denial Patterns</h2>
          <Button variant="ghost" size="sm">
            View All
            <ChevronRight className="ml-1 h-4 w-4" />
          </Button>
        </div>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {patternCards.map((pattern) => (
            <Card
              key={pattern.id}
              className={`cursor-pointer border-l-4 transition-all hover:shadow-md ${pattern.color}`}
            >
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{pattern.payer}</span>
                      <Badge variant="outline" className="text-xs">
                        {pattern.cptCode}
                      </Badge>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {pattern.category}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-lg font-bold">
                      {pattern.count}
                    </Badge>
                    {pattern.trend === "up" && (
                      <TrendingUp className="h-4 w-4 text-risk" />
                    )}
                    {pattern.trend === "down" && (
                      <TrendingDown className="h-4 w-4 text-success" />
                    )}
                  </div>
                </div>
                <div className="mt-3 flex items-center justify-between">
                  <Button variant="link" size="sm" className="h-auto p-0 text-xs">
                    View affected claims →
                  </Button>
                  <Button variant="ghost" size="sm" className="h-7">
                    <Lightbulb className="mr-1 h-3 w-3" />
                    Create Rule
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
