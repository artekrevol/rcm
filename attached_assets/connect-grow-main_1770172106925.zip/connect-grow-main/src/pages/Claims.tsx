import { useState } from "react";
import {
  Search,
  Filter,
  AlertTriangle,
  ChevronDown,
  ChevronRight,
  ExternalLink,
  FileText,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";

interface Claim {
  id: string;
  payer: string;
  cptCodes: string[];
  amount: number;
  riskScore: number;
  readiness: number;
  status: "pending" | "submitted" | "denied" | "paid" | "appealing";
  reason: string;
  nextStep: string;
  patientName: string;
  dateOfService: string;
}

const claimsData: Claim[] = [
  {
    id: "CLM-2024-001",
    payer: "Aetna",
    cptCodes: ["99213", "90837"],
    amount: 2450,
    riskScore: 85,
    readiness: 60,
    status: "pending",
    reason: "Missing prior auth",
    nextStep: "Obtain PA-12345",
    patientName: "John Smith",
    dateOfService: "2024-01-10",
  },
  {
    id: "CLM-2024-002",
    payer: "United Healthcare",
    cptCodes: ["99214"],
    amount: 1800,
    riskScore: 45,
    readiness: 90,
    status: "submitted",
    reason: "Awaiting payer response",
    nextStep: "Follow up in 5 days",
    patientName: "Maria Garcia",
    dateOfService: "2024-01-08",
  },
  {
    id: "CLM-2024-003",
    payer: "Cigna",
    cptCodes: ["99215", "90834"],
    amount: 3200,
    riskScore: 92,
    readiness: 40,
    status: "denied",
    reason: "Medical necessity",
    nextStep: "Submit appeal with docs",
    patientName: "Robert Johnson",
    dateOfService: "2024-01-05",
  },
  {
    id: "CLM-2024-004",
    payer: "Blue Cross",
    cptCodes: ["99213"],
    amount: 1250,
    riskScore: 15,
    readiness: 100,
    status: "paid",
    reason: "Claim processed",
    nextStep: "Complete",
    patientName: "Emily Chen",
    dateOfService: "2024-01-03",
  },
  {
    id: "CLM-2024-005",
    payer: "Aetna",
    cptCodes: ["90837", "90785"],
    amount: 2800,
    riskScore: 72,
    readiness: 75,
    status: "appealing",
    reason: "Timely filing dispute",
    nextStep: "Await appeal decision",
    patientName: "David Williams",
    dateOfService: "2023-12-28",
  },
];

const statusColors: Record<string, { bg: string; text: string }> = {
  pending: { bg: "bg-warning/10", text: "text-warning" },
  submitted: { bg: "bg-primary/10", text: "text-primary" },
  denied: { bg: "bg-risk/10", text: "text-risk" },
  paid: { bg: "bg-success/10", text: "text-success" },
  appealing: { bg: "bg-chart-4/10", text: "text-chart-4" },
};

function getRiskColor(score: number) {
  if (score >= 70) return "bg-risk";
  if (score >= 40) return "bg-warning";
  return "bg-success";
}

function ClaimRow({ claim }: { claim: Claim }) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <TableRow className="group">
        <TableCell>
          <CollapsibleTrigger asChild>
            <Button variant="ghost" size="icon" className="h-6 w-6">
              {isOpen ? (
                <ChevronDown className="h-4 w-4" />
              ) : (
                <ChevronRight className="h-4 w-4" />
              )}
            </Button>
          </CollapsibleTrigger>
        </TableCell>
        <TableCell className="font-medium">{claim.id}</TableCell>
        <TableCell>{claim.payer}</TableCell>
        <TableCell>
          <div className="flex gap-1">
            {claim.cptCodes.map((code) => (
              <Badge key={code} variant="outline" className="text-xs">
                {code}
              </Badge>
            ))}
          </div>
        </TableCell>
        <TableCell className="font-medium">
          ${claim.amount.toLocaleString()}
        </TableCell>
        <TableCell>
          <div className="flex items-center gap-2">
            <div className={`h-2 w-2 rounded-full ${getRiskColor(claim.riskScore)}`} />
            <span className="font-medium">{claim.riskScore}</span>
          </div>
        </TableCell>
        <TableCell>
          <div className="flex items-center gap-2">
            <Progress value={claim.readiness} className="h-2 w-16" />
            <span className="text-sm text-muted-foreground">
              {claim.readiness}%
            </span>
          </div>
        </TableCell>
        <TableCell>
          <Badge
            className={`${statusColors[claim.status].bg} ${statusColors[claim.status].text}`}
          >
            {claim.status}
          </Badge>
        </TableCell>
        <TableCell className="text-muted-foreground">{claim.reason}</TableCell>
        <TableCell>
          <span className="text-sm text-primary">{claim.nextStep}</span>
        </TableCell>
      </TableRow>
      <CollapsibleContent asChild>
        <tr>
          <td colSpan={10} className="bg-muted/30 p-4">
            <div className="grid gap-4 sm:grid-cols-3">
              <div>
                <p className="text-sm font-medium">Patient</p>
                <p className="text-sm text-muted-foreground">{claim.patientName}</p>
              </div>
              <div>
                <p className="text-sm font-medium">Date of Service</p>
                <p className="text-sm text-muted-foreground">{claim.dateOfService}</p>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <FileText className="mr-2 h-4 w-4" />
                  View Details
                </Button>
                <Button size="sm">Take Action</Button>
              </div>
            </div>
          </td>
        </tr>
      </CollapsibleContent>
    </Collapsible>
  );
}

export default function Claims() {
  const atRiskCount = claimsData.filter((c) => c.riskScore >= 70).length;

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Claims Management
          </h1>
          <p className="text-sm text-muted-foreground">
            Monitor and manage claim submissions
          </p>
        </div>
        <Button size="sm">
          <ExternalLink className="mr-2 h-4 w-4" />
          Export Claims
        </Button>
      </div>

      {/* Alert Banner */}
      {atRiskCount > 0 && (
        <Card className="border-warning bg-warning/5">
          <CardContent className="flex items-center gap-3 p-4">
            <AlertTriangle className="h-5 w-5 text-warning" />
            <div className="flex-1">
              <p className="font-medium">
                {atRiskCount} claim{atRiskCount > 1 ? "s" : ""} at high risk
              </p>
              <p className="text-sm text-muted-foreground">
                Review and take action to prevent denials
              </p>
            </div>
            <Button variant="outline" size="sm">
              View At-Risk Claims
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Filters */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1 sm:max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search claims, patients, or payers..." className="pl-10" />
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            Status
            <ChevronDown className="ml-2 h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm">
            Payer
            <ChevronDown className="ml-2 h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm">
            Risk Level
            <ChevronDown className="ml-2 h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Claims Table */}
      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-10"></TableHead>
              <TableHead>Claim ID</TableHead>
              <TableHead>Payer</TableHead>
              <TableHead>CPT Codes</TableHead>
              <TableHead>Amount</TableHead>
              <TableHead>Risk</TableHead>
              <TableHead>Readiness</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Reason</TableHead>
              <TableHead>Next Step</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {claimsData.map((claim) => (
              <ClaimRow key={claim.id} claim={claim} />
            ))}
          </TableBody>
        </Table>
      </Card>

      {/* Risk Legend */}
      <Card>
        <CardContent className="flex flex-wrap items-center gap-6 p-4">
          <span className="text-sm font-medium">Risk Score Legend:</span>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-success" />
            <span className="text-sm text-muted-foreground">Low (0-39)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-warning" />
            <span className="text-sm text-muted-foreground">Medium (40-69)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="h-3 w-3 rounded-full bg-risk" />
            <span className="text-sm text-muted-foreground">High (70-100)</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
