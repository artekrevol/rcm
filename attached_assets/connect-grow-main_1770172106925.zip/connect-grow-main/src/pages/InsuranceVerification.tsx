import { useState } from "react";
import {
  Search,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Download,
  Calendar,
  Clock,
  Building2,
  User,
  CreditCard,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";

interface VOBResult {
  verified: boolean;
  inNetwork: boolean;
  patientName: string;
  memberId: string;
  payer: string;
  planName: string;
  groupNumber: string;
  effectiveDate: string;
  terminationDate: string;
  benefits: {
    deductible: { total: number; met: number };
    outOfPocket: { total: number; met: number };
    coinsurance: number;
    copay: number;
  };
  priorAuth: {
    required: boolean;
    status: "approved" | "pending" | "denied" | "not_required";
    authNumber?: string;
    expirationDate?: string;
  };
}

const mockResult: VOBResult = {
  verified: true,
  inNetwork: true,
  patientName: "John Smith",
  memberId: "XYZ123456789",
  payer: "Aetna",
  planName: "Aetna PPO Gold",
  groupNumber: "GRP-8834521",
  effectiveDate: "2024-01-01",
  terminationDate: "2024-12-31",
  benefits: {
    deductible: { total: 2500, met: 1850 },
    outOfPocket: { total: 6500, met: 3200 },
    coinsurance: 20,
    copay: 35,
  },
  priorAuth: {
    required: true,
    status: "approved",
    authNumber: "PA-2024-78542",
    expirationDate: "2024-03-15",
  },
};

export default function InsuranceVerification() {
  const [searchMemberId, setSearchMemberId] = useState("");
  const [searchDOB, setSearchDOB] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<VOBResult | null>(null);

  const handleVerify = () => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setResult(mockResult);
      setIsLoading(false);
    }, 1500);
  };

  const deductiblePct = (result?.benefits.deductible.met || 0) / (result?.benefits.deductible.total || 1) * 100;
  const oopPct = (result?.benefits.outOfPocket.met || 0) / (result?.benefits.outOfPocket.total || 1) * 100;

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Insurance Verification (VOB)
          </h1>
          <p className="text-sm text-muted-foreground">
            Verify patient insurance and benefits in real-time
          </p>
        </div>
      </div>

      {/* Search Form */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base font-medium">Verify Insurance</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 sm:grid-cols-4">
            <div className="grid gap-2">
              <Label>Payer</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input placeholder="Search payer..." className="pl-10" />
              </div>
            </div>
            <div className="grid gap-2">
              <Label>Member ID</Label>
              <Input
                placeholder="Enter member ID"
                value={searchMemberId}
                onChange={(e) => setSearchMemberId(e.target.value)}
              />
            </div>
            <div className="grid gap-2">
              <Label>Date of Birth</Label>
              <Input
                type="date"
                value={searchDOB}
                onChange={(e) => setSearchDOB(e.target.value)}
              />
            </div>
            <div className="flex items-end">
              <Button
                className="w-full"
                onClick={handleVerify}
                disabled={isLoading}
              >
                {isLoading ? (
                  <>
                    <span className="animate-pulse">Verifying...</span>
                  </>
                ) : (
                  <>
                    <Search className="mr-2 h-4 w-4" />
                    Verify
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {result && (
        <div className="space-y-6 animate-fade-in">
          {/* Status Banner */}
          <Card
            className={`border-2 ${
              result.verified ? "border-success bg-success/5" : "border-risk bg-risk/5"
            }`}
          >
            <CardContent className="flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                {result.verified ? (
                  <CheckCircle2 className="h-8 w-8 text-success" />
                ) : (
                  <XCircle className="h-8 w-8 text-risk" />
                )}
                <div>
                  <p className="text-lg font-semibold">
                    {result.verified ? "Eligibility Verified" : "Verification Failed"}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {result.inNetwork ? "In-Network" : "Out-of-Network"} • {result.planName}
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Export PDF
                </Button>
                <Button size="sm">Save to Lead</Button>
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-6 lg:grid-cols-2">
            {/* Member Information */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base font-medium">
                  Member Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-muted p-2">
                    <User className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Patient Name</p>
                    <p className="font-medium">{result.patientName}</p>
                  </div>
                </div>
                <Separator />
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-muted p-2">
                    <CreditCard className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Member ID</p>
                    <p className="font-medium">{result.memberId}</p>
                  </div>
                </div>
                <Separator />
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-muted p-2">
                    <Building2 className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Payer / Plan</p>
                    <p className="font-medium">{result.payer}</p>
                    <p className="text-sm text-muted-foreground">{result.planName}</p>
                  </div>
                </div>
                <Separator />
                <div className="flex items-center gap-3">
                  <div className="rounded-lg bg-muted p-2">
                    <Calendar className="h-5 w-5 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Coverage Period</p>
                    <p className="font-medium">
                      {result.effectiveDate} – {result.terminationDate}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Benefits */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base font-medium">
                  Benefits Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Deductible */}
                <div>
                  <div className="mb-2 flex justify-between text-sm">
                    <span className="text-muted-foreground">Deductible</span>
                    <span className="font-medium">
                      ${result.benefits.deductible.met.toLocaleString()} / $
                      {result.benefits.deductible.total.toLocaleString()}
                    </span>
                  </div>
                  <div className="h-3 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full bg-primary transition-all"
                      style={{ width: `${deductiblePct}%` }}
                    />
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    ${(result.benefits.deductible.total - result.benefits.deductible.met).toLocaleString()} remaining
                  </p>
                </div>

                {/* Out-of-Pocket */}
                <div>
                  <div className="mb-2 flex justify-between text-sm">
                    <span className="text-muted-foreground">Out-of-Pocket Max</span>
                    <span className="font-medium">
                      ${result.benefits.outOfPocket.met.toLocaleString()} / $
                      {result.benefits.outOfPocket.total.toLocaleString()}
                    </span>
                  </div>
                  <div className="h-3 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full bg-success transition-all"
                      style={{ width: `${oopPct}%` }}
                    />
                  </div>
                  <p className="mt-1 text-xs text-muted-foreground">
                    ${(result.benefits.outOfPocket.total - result.benefits.outOfPocket.met).toLocaleString()} remaining
                  </p>
                </div>

                <Separator />

                {/* Cost Sharing */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="rounded-lg bg-muted/50 p-3 text-center">
                    <p className="text-2xl font-bold">{result.benefits.coinsurance}%</p>
                    <p className="text-sm text-muted-foreground">Coinsurance</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-3 text-center">
                    <p className="text-2xl font-bold">${result.benefits.copay}</p>
                    <p className="text-sm text-muted-foreground">Copay</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Prior Authorization */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">
                Prior Authorization
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap items-center gap-6">
                <div className="flex items-center gap-2">
                  {result.priorAuth.status === "approved" ? (
                    <CheckCircle2 className="h-5 w-5 text-success" />
                  ) : result.priorAuth.status === "pending" ? (
                    <Clock className="h-5 w-5 text-warning" />
                  ) : result.priorAuth.status === "denied" ? (
                    <XCircle className="h-5 w-5 text-risk" />
                  ) : (
                    <AlertCircle className="h-5 w-5 text-muted-foreground" />
                  )}
                  <Badge
                    className={
                      result.priorAuth.status === "approved"
                        ? "bg-success/10 text-success"
                        : result.priorAuth.status === "pending"
                        ? "bg-warning/10 text-warning"
                        : result.priorAuth.status === "denied"
                        ? "bg-risk/10 text-risk"
                        : "bg-muted text-muted-foreground"
                    }
                  >
                    {result.priorAuth.status.charAt(0).toUpperCase() +
                      result.priorAuth.status.slice(1)}
                  </Badge>
                </div>
                {result.priorAuth.authNumber && (
                  <div>
                    <span className="text-sm text-muted-foreground">Auth #: </span>
                    <span className="font-medium">{result.priorAuth.authNumber}</span>
                  </div>
                )}
                {result.priorAuth.expirationDate && (
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">Expires: </span>
                    <span className="font-medium">{result.priorAuth.expirationDate}</span>
                    <Badge variant="outline" className="text-warning">
                      Expires in 45 days
                    </Badge>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Empty State */}
      {!result && !isLoading && (
        <Card className="border-dashed">
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Search className="h-12 w-12 text-muted-foreground/50" />
            <p className="mt-4 text-lg font-medium">Verify Patient Insurance</p>
            <p className="text-sm text-muted-foreground">
              Enter payer and member details above to check eligibility and benefits
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
