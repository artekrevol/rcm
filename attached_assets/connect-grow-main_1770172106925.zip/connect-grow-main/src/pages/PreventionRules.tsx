import { useState } from "react";
import {
  Shield,
  Plus,
  Search,
  Zap,
  DollarSign,
  CheckCircle2,
  XCircle,
  Edit,
  Trash2,
  ChevronDown,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

interface Rule {
  id: string;
  name: string;
  description: string;
  payer: string;
  cptCodes: string[];
  triggerCount: number;
  preventionRate: number;
  active: boolean;
}

const rulesData: Rule[] = [
  {
    id: "R001",
    name: "Aetna Prior Auth Check",
    description: "Requires prior auth verification for all 99213-99215 codes",
    payer: "Aetna",
    cptCodes: ["99213", "99214", "99215"],
    triggerCount: 156,
    preventionRate: 94,
    active: true,
  },
  {
    id: "R002",
    name: "Cigna Medical Necessity",
    description: "Flag claims missing medical necessity documentation",
    payer: "Cigna",
    cptCodes: ["90837", "90834"],
    triggerCount: 89,
    preventionRate: 88,
    active: true,
  },
  {
    id: "R003",
    name: "UHC Timely Filing Alert",
    description: "Alert when claim approaches filing deadline",
    payer: "United Healthcare",
    cptCodes: ["All"],
    triggerCount: 234,
    preventionRate: 97,
    active: true,
  },
  {
    id: "R004",
    name: "Duplicate Claim Detection",
    description: "Prevent duplicate claim submissions",
    payer: "All",
    cptCodes: ["All"],
    triggerCount: 45,
    preventionRate: 100,
    active: true,
  },
  {
    id: "R005",
    name: "Blue Cross Eligibility",
    description: "Verify eligibility before submission",
    payer: "Blue Cross",
    cptCodes: ["All"],
    triggerCount: 67,
    preventionRate: 82,
    active: false,
  },
];

export default function PreventionRules() {
  const [rules, setRules] = useState(rulesData);
  const [searchQuery, setSearchQuery] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const activeRules = rules.filter((r) => r.active).length;
  const totalTriggers = rules.reduce((sum, r) => sum + r.triggerCount, 0);
  const avgPreventionRate = Math.round(
    rules.reduce((sum, r) => sum + r.preventionRate, 0) / rules.length
  );

  const toggleRule = (id: string) => {
    setRules(
      rules.map((rule) =>
        rule.id === id ? { ...rule, active: !rule.active } : rule
      )
    );
  };

  const filteredRules = rules.filter(
    (rule) =>
      rule.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      rule.payer.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Prevention Rules
          </h1>
          <p className="text-sm text-muted-foreground">
            Automated denial prevention rules
          </p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="mr-2 h-4 w-4" />
              Add Rule
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Create Prevention Rule</DialogTitle>
              <DialogDescription>
                Set up a new automated rule to prevent claim denials.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="name">Rule Name</Label>
                <Input id="name" placeholder="e.g., Aetna Prior Auth Check" />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  placeholder="Describe what this rule does..."
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label>Payer</Label>
                  <Button variant="outline" className="justify-between">
                    Select Payer
                    <ChevronDown className="h-4 w-4" />
                  </Button>
                </div>
                <div className="grid gap-2">
                  <Label>CPT Codes</Label>
                  <Input placeholder="99213, 99214, ..." />
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={() => setIsDialogOpen(false)}>Create Rule</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <Card className="card-hover">
          <CardContent className="flex items-center gap-4 p-6">
            <div className="rounded-lg bg-primary/10 p-3">
              <Shield className="h-6 w-6 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Active Rules</p>
              <p className="text-2xl font-bold">{activeRules}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="card-hover">
          <CardContent className="flex items-center gap-4 p-6">
            <div className="rounded-lg bg-warning/10 p-3">
              <Zap className="h-6 w-6 text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Times Triggered</p>
              <p className="text-2xl font-bold">{totalTriggers}</p>
            </div>
          </CardContent>
        </Card>
        <Card className="card-hover">
          <CardContent className="flex items-center gap-4 p-6">
            <div className="rounded-lg bg-success/10 p-3">
              <CheckCircle2 className="h-6 w-6 text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Denials Prevented</p>
              <p className="text-2xl font-bold">543</p>
            </div>
          </CardContent>
        </Card>
        <Card className="card-hover">
          <CardContent className="flex items-center gap-4 p-6">
            <div className="rounded-lg bg-chart-4/10 p-3">
              <DollarSign className="h-6 w-6 text-chart-4" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Revenue Protected</p>
              <p className="text-2xl font-bold">$1.3M</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1 sm:max-w-md">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search rules..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>

      {/* Rules Table */}
      <Card>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16">Active</TableHead>
              <TableHead>Rule Name</TableHead>
              <TableHead>Payer</TableHead>
              <TableHead>CPT Codes</TableHead>
              <TableHead>Triggers</TableHead>
              <TableHead>Prevention Rate</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredRules.map((rule) => (
              <TableRow key={rule.id} className="group">
                <TableCell>
                  <Switch
                    checked={rule.active}
                    onCheckedChange={() => toggleRule(rule.id)}
                  />
                </TableCell>
                <TableCell>
                  <div>
                    <p className="font-medium">{rule.name}</p>
                    <p className="text-sm text-muted-foreground">
                      {rule.description}
                    </p>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{rule.payer}</Badge>
                </TableCell>
                <TableCell>
                  <div className="flex flex-wrap gap-1">
                    {rule.cptCodes.slice(0, 3).map((code) => (
                      <Badge key={code} variant="secondary" className="text-xs">
                        {code}
                      </Badge>
                    ))}
                    {rule.cptCodes.length > 3 && (
                      <Badge variant="secondary" className="text-xs">
                        +{rule.cptCodes.length - 3}
                      </Badge>
                    )}
                  </div>
                </TableCell>
                <TableCell>
                  <span className="font-medium">{rule.triggerCount}</span>
                </TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-16 overflow-hidden rounded-full bg-muted">
                      <div
                        className="h-full bg-success"
                        style={{ width: `${rule.preventionRate}%` }}
                      />
                    </div>
                    <span className="text-sm text-muted-foreground">
                      {rule.preventionRate}%
                    </span>
                  </div>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8 text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
