import { useState } from "react";
import {
  MessageSquare,
  Users,
  Calendar,
  Clock,
  TrendingUp,
  Search,
  Filter,
  Phone,
  Mail,
  Eye,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  BarChart,
  Bar,
} from "recharts";

const analyticsMetrics = [
  {
    title: "Total Conversations",
    value: "1,284",
    change: "+18%",
    icon: MessageSquare,
  },
  {
    title: "Leads Generated",
    value: "342",
    subtitle: "26.6% conversion",
    change: "+12%",
    icon: Users,
  },
  {
    title: "Appointments Booked",
    value: "89",
    change: "+24%",
    icon: Calendar,
  },
  {
    title: "Avg Duration",
    value: "4:32",
    change: "-8%",
    icon: Clock,
  },
];

const trendData = [
  { date: "Mon", leads: 45, conversations: 120 },
  { date: "Tue", leads: 52, conversations: 145 },
  { date: "Wed", leads: 48, conversations: 132 },
  { date: "Thu", leads: 61, conversations: 168 },
  { date: "Fri", leads: 55, conversations: 155 },
  { date: "Sat", leads: 42, conversations: 98 },
  { date: "Sun", leads: 38, conversations: 85 },
];

const funnelData = [
  { name: "Started Chat", value: 1284, fill: "hsl(var(--chart-1))" },
  { name: "Provided Info", value: 856, fill: "hsl(var(--chart-2))" },
  { name: "Qualified Lead", value: 342, fill: "hsl(var(--chart-3))" },
  { name: "Booked", value: 89, fill: "hsl(var(--chart-4))" },
];

const dropoffData = [
  { stage: "Welcome", dropoff: 5 },
  { stage: "Treatment", dropoff: 12 },
  { stage: "Beneficiary", dropoff: 8 },
  { stage: "Contact", dropoff: 22 },
  { stage: "Info Entry", dropoff: 35 },
  { stage: "Insurance", dropoff: 18 },
];

const leadsData = [
  {
    id: "L001",
    name: "Sarah Johnson",
    phone: "(555) 123-4567",
    status: "new",
    priority: "P0",
    source: "Chat Widget",
    date: "2024-01-15",
  },
  {
    id: "L002",
    name: "Michael Chen",
    phone: "(555) 234-5678",
    status: "contacted",
    priority: "P1",
    source: "Chat Widget",
    date: "2024-01-15",
  },
  {
    id: "L003",
    name: "Emily Rodriguez",
    phone: "(555) 345-6789",
    status: "qualified",
    priority: "P0",
    source: "Inbound Call",
    date: "2024-01-14",
  },
  {
    id: "L004",
    name: "David Thompson",
    phone: "(555) 456-7890",
    status: "new",
    priority: "P2",
    source: "Chat Widget",
    date: "2024-01-14",
  },
  {
    id: "L005",
    name: "Jessica Williams",
    phone: "(555) 567-8901",
    status: "contacted",
    priority: "P1",
    source: "Chat Widget",
    date: "2024-01-13",
  },
];

const statusColors: Record<string, string> = {
  new: "bg-primary",
  contacted: "bg-warning",
  qualified: "bg-success",
  unqualified: "bg-muted",
};

const priorityColors: Record<string, string> = {
  P0: "bg-risk text-risk-foreground",
  P1: "bg-warning text-warning-foreground",
  P2: "bg-muted text-muted-foreground",
};

export default function LeadAnalytics() {
  const [activeTab, setActiveTab] = useState("analytics");

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">
            Lead Analytics
          </h1>
          <p className="text-sm text-muted-foreground">
            Chat performance and lead insights
          </p>
        </div>
        <Button size="sm">
          <TrendingUp className="mr-2 h-4 w-4" />
          Export Report
        </Button>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="leads">All Leads</TabsTrigger>
          <TabsTrigger value="conversations">Conversations</TabsTrigger>
        </TabsList>

        <TabsContent value="analytics" className="mt-6 space-y-6">
          {/* Metrics row */}
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {analyticsMetrics.map((metric) => (
              <Card key={metric.title} className="card-hover">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="space-y-2">
                      <p className="text-sm font-medium text-muted-foreground">
                        {metric.title}
                      </p>
                      <p className="text-3xl font-bold tracking-tight">
                        {metric.value}
                      </p>
                      {metric.subtitle && (
                        <p className="text-xs text-muted-foreground">
                          {metric.subtitle}
                        </p>
                      )}
                      <p className="text-sm text-success">{metric.change}</p>
                    </div>
                    <div className="rounded-lg bg-muted p-2">
                      <metric.icon className="h-5 w-5 text-muted-foreground" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Charts */}
          <div className="grid gap-6 lg:grid-cols-2">
            {/* Trend Chart */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base font-medium">
                  Weekly Trends
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[280px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={trendData}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                      <XAxis dataKey="date" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <YAxis stroke="hsl(var(--muted-foreground))" fontSize={12} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px",
                        }}
                      />
                      <Line
                        type="monotone"
                        dataKey="conversations"
                        stroke="hsl(var(--chart-1))"
                        strokeWidth={2}
                        dot={false}
                        name="Conversations"
                      />
                      <Line
                        type="monotone"
                        dataKey="leads"
                        stroke="hsl(var(--chart-2))"
                        strokeWidth={2}
                        dot={false}
                        name="Leads"
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>

            {/* Funnel */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base font-medium">
                  Conversion Funnel
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[280px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={funnelData}
                        cx="50%"
                        cy="50%"
                        innerRadius={60}
                        outerRadius={100}
                        paddingAngle={2}
                        dataKey="value"
                      >
                        {funnelData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.fill} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: "8px",
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-4 flex flex-wrap justify-center gap-4">
                  {funnelData.map((item) => (
                    <div key={item.name} className="flex items-center gap-2">
                      <div
                        className="h-3 w-3 rounded-full"
                        style={{ backgroundColor: item.fill }}
                      />
                      <span className="text-xs text-muted-foreground">
                        {item.name}: {item.value}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Drop-off Analysis */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base font-medium">
                Drop-off Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[200px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={dropoffData} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis type="number" stroke="hsl(var(--muted-foreground))" fontSize={12} />
                    <YAxis
                      type="category"
                      dataKey="stage"
                      stroke="hsl(var(--muted-foreground))"
                      fontSize={12}
                      width={80}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "hsl(var(--card))",
                        border: "1px solid hsl(var(--border))",
                        borderRadius: "8px",
                      }}
                    />
                    <Bar dataKey="dropoff" fill="hsl(var(--chart-5))" radius={[0, 4, 4, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="leads" className="mt-6 space-y-4">
          {/* Filters */}
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search leads..." className="pl-10" />
            </div>
            <Button variant="outline" size="sm">
              <Filter className="mr-2 h-4 w-4" />
              Filters
            </Button>
          </div>

          {/* Table */}
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Phone</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Priority</TableHead>
                  <TableHead>Source</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {leadsData.map((lead) => (
                  <TableRow key={lead.id} className="group">
                    <TableCell className="font-medium">{lead.name}</TableCell>
                    <TableCell>{lead.phone}</TableCell>
                    <TableCell>
                      <Badge
                        variant="secondary"
                        className={statusColors[lead.status]}
                      >
                        {lead.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <Badge className={priorityColors[lead.priority]}>
                        {lead.priority}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {lead.source}
                    </TableCell>
                    <TableCell className="text-muted-foreground">
                      {lead.date}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Phone className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Mail className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>

          {/* Pagination */}
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Showing 1-5 of 342 leads
            </p>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" className="h-8 w-8">
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" className="h-8 w-8">
                1
              </Button>
              <Button variant="ghost" size="sm" className="h-8 w-8">
                2
              </Button>
              <Button variant="ghost" size="sm" className="h-8 w-8">
                3
              </Button>
              <Button variant="outline" size="icon" className="h-8 w-8">
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="conversations" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <p className="text-center text-muted-foreground">
                Conversations view coming soon...
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
