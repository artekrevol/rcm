import { useState } from "react";
import {
  Plus,
  LayoutGrid,
  List,
  Search,
  Filter,
  Phone,
  Mail,
  MessageSquare,
  MoreHorizontal,
  GripVertical,
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

type ViewMode = "board" | "list";
type Stage = "new" | "contacted" | "qualified" | "unqualified" | "converted";

interface Lead {
  id: string;
  name: string;
  phone: string;
  priority: "P0" | "P1" | "P2";
  stage: Stage;
  lastActivity: string;
  source: string;
}

const leadsData: Lead[] = [
  { id: "1", name: "Sarah Johnson", phone: "(555) 123-4567", priority: "P0", stage: "new", lastActivity: "2 min ago", source: "Chat" },
  { id: "2", name: "Michael Chen", phone: "(555) 234-5678", priority: "P1", stage: "new", lastActivity: "15 min ago", source: "Call" },
  { id: "3", name: "Emily Rodriguez", phone: "(555) 345-6789", priority: "P0", stage: "contacted", lastActivity: "1 hour ago", source: "Chat" },
  { id: "4", name: "David Thompson", phone: "(555) 456-7890", priority: "P2", stage: "contacted", lastActivity: "2 hours ago", source: "Chat" },
  { id: "5", name: "Jessica Williams", phone: "(555) 567-8901", priority: "P1", stage: "qualified", lastActivity: "3 hours ago", source: "Call" },
  { id: "6", name: "Robert Brown", phone: "(555) 678-9012", priority: "P0", stage: "qualified", lastActivity: "5 hours ago", source: "Chat" },
  { id: "7", name: "Amanda Davis", phone: "(555) 789-0123", priority: "P2", stage: "unqualified", lastActivity: "1 day ago", source: "Chat" },
  { id: "8", name: "Christopher Lee", phone: "(555) 890-1234", priority: "P1", stage: "converted", lastActivity: "2 days ago", source: "Call" },
];

const stages: { id: Stage; label: string; color: string }[] = [
  { id: "new", label: "New", color: "bg-primary" },
  { id: "contacted", label: "Contacted", color: "bg-warning" },
  { id: "qualified", label: "Qualified", color: "bg-success" },
  { id: "unqualified", label: "Unqualified", color: "bg-muted" },
  { id: "converted", label: "Converted", color: "bg-chart-4" },
];

const priorityColors: Record<string, string> = {
  P0: "bg-risk text-risk-foreground",
  P1: "bg-warning text-warning-foreground",
  P2: "bg-muted text-muted-foreground",
};

function LeadCard({ lead }: { lead: Lead }) {
  return (
    <div className="group cursor-grab rounded-lg border bg-card p-3 shadow-sm transition-all hover:shadow-md active:cursor-grabbing">
      <div className="mb-2 flex items-start justify-between">
        <div className="flex items-center gap-2">
          <GripVertical className="h-4 w-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
          <div>
            <p className="font-medium">{lead.name}</p>
            <p className="text-sm text-muted-foreground">{lead.phone}</p>
          </div>
        </div>
        <Badge className={priorityColors[lead.priority]}>{lead.priority}</Badge>
      </div>
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">{lead.lastActivity}</span>
        <div className="flex gap-1 opacity-0 transition-opacity group-hover:opacity-100">
          <Button variant="ghost" size="icon" className="h-7 w-7">
            <Phone className="h-3 w-3" />
          </Button>
          <Button variant="ghost" size="icon" className="h-7 w-7">
            <MessageSquare className="h-3 w-3" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-7 w-7">
                <MoreHorizontal className="h-3 w-3" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>View Details</DropdownMenuItem>
              <DropdownMenuItem>Edit Lead</DropdownMenuItem>
              <DropdownMenuItem>Add Note</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
}

export default function Deals() {
  const [viewMode, setViewMode] = useState<ViewMode>("board");
  const [leads] = useState(leadsData);

  const getLeadsByStage = (stage: Stage) =>
    leads.filter((lead) => lead.stage === stage);

  return (
    <div className="space-y-6">
      {/* Page header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Deals</h1>
          <p className="text-sm text-muted-foreground">
            Manage your lead pipeline
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex rounded-lg border p-1">
            <Button
              variant={viewMode === "board" ? "secondary" : "ghost"}
              size="sm"
              className="h-8"
              onClick={() => setViewMode("board")}
            >
              <LayoutGrid className="mr-2 h-4 w-4" />
              Board
            </Button>
            <Button
              variant={viewMode === "list" ? "secondary" : "ghost"}
              size="sm"
              className="h-8"
              onClick={() => setViewMode("list")}
            >
              <List className="mr-2 h-4 w-4" />
              List
            </Button>
          </div>
          <Button size="sm">
            <Plus className="mr-2 h-4 w-4" />
            Add Lead
          </Button>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
        <div className="relative flex-1 sm:max-w-xs">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search leads..." className="pl-10" />
        </div>
        <Button variant="outline" size="sm">
          <Filter className="mr-2 h-4 w-4" />
          Filters
        </Button>
      </div>

      {viewMode === "board" ? (
        /* Kanban Board */
        <div className="flex gap-4 overflow-x-auto pb-4">
          {stages.map((stage) => {
            const stageLeads = getLeadsByStage(stage.id);
            return (
              <div
                key={stage.id}
                className="flex w-72 shrink-0 flex-col rounded-lg bg-muted/50"
              >
                {/* Column Header */}
                <div className="flex items-center justify-between border-b bg-muted/80 p-3">
                  <div className="flex items-center gap-2">
                    <div className={`h-2 w-2 rounded-full ${stage.color}`} />
                    <span className="font-medium">{stage.label}</span>
                    <Badge variant="secondary" className="ml-1">
                      {stageLeads.length}
                    </Badge>
                  </div>
                  <Button variant="ghost" size="icon" className="h-7 w-7">
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>

                {/* Cards */}
                <div className="flex-1 space-y-2 p-2">
                  {stageLeads.map((lead) => (
                    <LeadCard key={lead.id} lead={lead} />
                  ))}
                  {stageLeads.length === 0 && (
                    <div className="rounded-lg border-2 border-dashed p-4 text-center text-sm text-muted-foreground">
                      No leads
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* List View */
        <Card>
          <CardContent className="p-0">
            <table className="w-full">
              <thead>
                <tr className="border-b bg-muted/50">
                  <th className="p-3 text-left text-sm font-medium">Name</th>
                  <th className="p-3 text-left text-sm font-medium">Phone</th>
                  <th className="p-3 text-left text-sm font-medium">Stage</th>
                  <th className="p-3 text-left text-sm font-medium">Priority</th>
                  <th className="p-3 text-left text-sm font-medium">Source</th>
                  <th className="p-3 text-left text-sm font-medium">Last Activity</th>
                  <th className="p-3 text-right text-sm font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {leads.map((lead) => (
                  <tr key={lead.id} className="group border-b transition-colors hover:bg-muted/50">
                    <td className="p-3 font-medium">{lead.name}</td>
                    <td className="p-3 text-muted-foreground">{lead.phone}</td>
                    <td className="p-3">
                      <Badge
                        variant="secondary"
                        className={stages.find((s) => s.id === lead.stage)?.color}
                      >
                        {lead.stage}
                      </Badge>
                    </td>
                    <td className="p-3">
                      <Badge className={priorityColors[lead.priority]}>
                        {lead.priority}
                      </Badge>
                    </td>
                    <td className="p-3 text-muted-foreground">{lead.source}</td>
                    <td className="p-3 text-muted-foreground">{lead.lastActivity}</td>
                    <td className="p-3 text-right">
                      <div className="flex justify-end gap-1 opacity-0 transition-opacity group-hover:opacity-100">
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Phone className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <Mail className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="icon" className="h-8 w-8">
                          <MessageSquare className="h-4 w-4" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
