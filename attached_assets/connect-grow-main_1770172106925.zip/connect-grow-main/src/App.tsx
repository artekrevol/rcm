import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AppLayout } from "@/components/layout/AppLayout";
import { ChatWidget } from "@/components/chat/ChatWidget";
import Dashboard from "./pages/Dashboard";
import LeadAnalytics from "./pages/LeadAnalytics";
import Deals from "./pages/Deals";
import Claims from "./pages/Claims";
import DenialIntelligence from "./pages/DenialIntelligence";
import PreventionRules from "./pages/PreventionRules";
import InsuranceVerification from "./pages/InsuranceVerification";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <AppLayout>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/analytics" element={<LeadAnalytics />} />
            <Route path="/deals" element={<Deals />} />
            <Route path="/claims" element={<Claims />} />
            <Route path="/denials" element={<DenialIntelligence />} />
            <Route path="/rules" element={<PreventionRules />} />
            <Route path="/vob" element={<InsuranceVerification />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </AppLayout>
        <ChatWidget />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
